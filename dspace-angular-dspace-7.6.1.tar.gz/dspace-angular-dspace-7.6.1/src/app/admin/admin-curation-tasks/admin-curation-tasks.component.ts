import { Component } from '@angular/core';

/**
 * Component responsible for rendering the system wide Curation Task UI
 */
@Component({
  selector: 'ds-admin-curation-task',
  templateUrl: './admin-curation-tasks.component.html',
})
export class AdminCurationTasksComponent {

}
