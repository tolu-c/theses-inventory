export interface CacheEntry {
  timeCompleted: number;
  msToLive: number;
}
